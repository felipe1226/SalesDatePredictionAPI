USE [StoreSample]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [Production].[PA_GetProducts] 
AS
BEGIN
	SELECT 
		productid,
		productname
	FROM Production.Products
	ORDER BY productname;
END
