USE [StoreSample]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [Sales].[PA_AddNewOrder]
	@CustomerId		int,
	@EmpId			int,
	@ShipperId		int,
	@ShipName		nvarchar(40),
	@ShipAddress	nvarchar(60),
	@ShipCity		nvarchar(15),
	@OrderDate		datetime,
	@RequiredDate	datetime,
	@ShippedDate	datetime,
	@Freight		money,
	@ShipCountry	nvarchar(15),
	@ProductId		int,
	@UnitPrice		money,
	@Qty			smallint,
	@Discount		numeric(4,3)


AS
BEGIN
	DECLARE @OrderId INT;

	INSERT INTO Orders (custid, Empid, Shipperid, Shipname, Shipaddress, Shipcity, Orderdate, Requireddate, Shippeddate, Freight, Shipcountry)
	VALUES (@CustomerId, @EmpId, @ShipperId, @ShipName, @ShipAddress, @ShipCity, @OrderDate, @RequiredDate, @ShippedDate, @Freight, @ShipCountry);

	SET @OrderId = SCOPE_IDENTITY();

	INSERT INTO OrderDetails (Orderid, Productid, Unitprice, Qty, Discount)
	VALUES (@OrderId, @ProductId, @Unitprice, @Qty, @Discount);
END
