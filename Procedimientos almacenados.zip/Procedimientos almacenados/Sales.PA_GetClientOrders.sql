USE [StoreSample]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [Sales].[PA_GetClientOrders] 
	@CustomerId int
AS
BEGIN
	SELECT 
		orderid,
		requireddate,
		shippeddate,
		shipname,
		shipaddress,
		shipcity
	FROM Sales.Orders
	WHERE custid = @CustomerId;
END
