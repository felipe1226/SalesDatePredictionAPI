USE [StoreSample]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [Sales].[PA_GetShippers] 
AS
BEGIN
	SELECT 
		shipperid,
		companyname
	FROM Sales.Shippers
	ORDER BY companyname;
END
