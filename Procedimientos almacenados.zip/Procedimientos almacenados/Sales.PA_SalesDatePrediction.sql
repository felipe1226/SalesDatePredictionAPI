USE [StoreSample]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [Sales].[PA_SalesDatePrediction] 
	@CustomerName nvarchar(40) = NULL
AS
BEGIN
	-- Se crea una tabla temporal para almacenar las �rdenes con la respectiva orden previa
	IF OBJECT_ID('tempdb..#ClientOrders') IS NOT NULL DROP TABLE #ClientOrders;
	SELECT 
		o.custid,
		o.orderdate,
		LAG(o.orderdate) OVER (PARTITION BY o.custid ORDER BY o.orderdate) AS previousorderdate
	INTO #ClientOrders
	FROM Sales.Orders o
	INNER JOIN Sales.Customers c ON o.custid = c.custid
    WHERE (@CustomerName IS NULL OR @CustomerName = '' OR LOWER(c.companyname) LIKE '%' + LOWER(@CustomerName) + '%');

	-- Se crea una tabla temporal para calcular los intervalos de d�as entre las �rdenes
	IF OBJECT_ID('tempdb..#OrderIntervals') IS NOT NULL DROP TABLE #OrderIntervals;
	SELECT 
		custid,
		DATEDIFF(DAY, previousorderdate, orderdate) AS intervaldays
	INTO #OrderIntervals
	FROM #ClientOrders
	WHERE previousorderdate IS NOT NULL;

	-- Se crear una tabla temporal para almacenar el promedio de d�as entre �rdenes por cliente
	IF OBJECT_ID('tempdb..#AverageIntervals') IS NOT NULL DROP TABLE #AverageIntervals;
	SELECT 
		custid,
		AVG(intervaldays) AS avgdays
	INTO #AverageIntervals
	FROM #OrderIntervals
	GROUP BY custid;

	-- Se obtienen los datos de la fecha de la �ltima orden y la predicci�n de la siguiente orden por cliente
	SELECT 
		c.custid AS CustomerId,
		c.companyname AS CustomerName,
		MAX(o.orderdate) AS LastOrderDate,
		DATEADD(DAY, COALESCE(ai.avgdays, 30), MAX(o.orderdate)) AS NextPredictedOrder
	FROM Sales.Orders o
	INNER JOIN Sales.Customers c ON o.custid = c.custid
	LEFT JOIN #AverageIntervals ai ON o.custid = ai.custid
	WHERE (@CustomerName IS NULL OR @CustomerName = '' OR LOWER(c.companyname) LIKE '%' + LOWER(@CustomerName) + '%')
	GROUP BY c.custid, c.companyname, ai.avgdays
	ORDER BY NextPredictedOrder;

	-- Se limpian las tablas temporales
	DROP TABLE IF EXISTS #OrderDifferences;
	DROP TABLE IF EXISTS #OrderIntervals;
	DROP TABLE IF EXISTS #AverageIntervals;
END
