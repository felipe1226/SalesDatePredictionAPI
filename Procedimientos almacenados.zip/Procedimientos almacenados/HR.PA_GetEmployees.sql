USE [StoreSample]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [HR].[PA_GetEmployees]
AS
BEGIN
	SELECT 
		empid,
		CONCAT(firstname, ' ', lastname) AS fullname
	FROM HR.Employees
	ORDER BY fullname;
END
